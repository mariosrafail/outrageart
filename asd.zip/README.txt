Run a local server to preview:
python -m http.server
# open http://localhost:8000

Edit data/items.json and set your external links:
- Dropbox: use ?dl=1
- Nextcloud: append /download
Thumbnails are local WEBP in /assets/thumbs/ for fast grids.
